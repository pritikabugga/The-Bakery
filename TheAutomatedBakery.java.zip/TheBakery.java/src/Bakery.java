import java.util.ArrayList;


public class Bakery {

    ArrayList<Dessert> items = new ArrayList(); //array is initialized




    /**
     * Constructor. Calls helper method that generates arraylist of items
     */
    public Bakery() {

        generateItems();

    }




    private void generateItems() {

        Cupcake cupcake1 = new Cupcake("Vanilla", 2.5, 10, "Chocolate", "Gummy bears");
        Cupcake cupcake2 = new Cupcake("Red Velvet", 3, 20, "Rainbow", "Gumballs");
        IceCream iceCream1 = new IceCream("Chocolate", 3.0, 8, "Caramel", 2);
        IceCream iceCream2 = new IceCream("Pistachio", 4.0, 9, "Chocolate", 3);
        Cookie cookie1 = new Cookie("Oatmeal", 1.8, 12, false, true);
        Cookie cookie2 = new Cookie("Sugar", 2.0, 40, false, false);
        Cookie cookie3 = new Cookie("Double Chocolate Chip", 3.5, 23, true, false);

        items.add(cupcake1);
        items.add(cupcake2);
        items.add(iceCream1);
        items.add(iceCream2);
        items.add(cookie1);
        items.add(cookie2);
        items.add(cookie3);



    }







    /**
     * Getter for items
     * @return ArrayList of Desserts
     */
    public ArrayList<Dessert> getItems() {
        return items;
    }








}
