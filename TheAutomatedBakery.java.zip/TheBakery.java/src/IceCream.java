public class IceCream extends Dessert {
    private String syrup;
    private int scoops;


    public IceCream(String flavor, double price, int quantity, String syrup, int scoops) {
        super(flavor, price, quantity);
        this.syrup = syrup;
        this.scoops = scoops;
    }


    // Getters and setters for IceCream specific attributes
    public String getSyrup() {
        return syrup;
    }


    public void setSyrup(String syrup) {
        this.syrup = syrup;
    }


    public int getScoops() {
        return scoops;
    }


    public void setScoops(int scoops) {
        this.scoops = scoops;
    }


    @Override
    public String toString() {
        return super.toString() + ", Syrup: " + syrup + ", Maximum Scoops: " + scoops;
    }
}
