public class Dessert {
    private String flavor;
    private double price;
    private int quantity;

    public Dessert(String flavor, double price, int quantity) {
        this.flavor = flavor;
        this.price = price;
        this.quantity = quantity;
    }

    // Getters and setters
    public String getFlavor() {
        return flavor;
    }

    public void setFlavor(String flavor) {
        this.flavor = flavor;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // toString() method
    @Override
    public String toString() {
        return "Flavor: " + flavor + ", Price: $" + price + ", Quantity: " + quantity;
    }

    // Overloaded methods for applying discount
    public void applyDiscount(double discountValue) {
        if (discountValue >= 5 && discountValue <= 40) {
            // Percentage discount
            double discountAmount = price * (discountValue / 100.0); // Calculate the discount amount
            double discountedPrice = price - discountAmount; // Calculate the discounted price
            this.price = discountedPrice;
            System.out.println("Discount of " + discountValue + "% applied successfully to " + getType() + " (" + flavor + ") Discounted price: $" + discountedPrice);
        } else {
            System.out.println("Invalid discount percentage. Please enter a percentage between 5 and 40 for " + getType() + " (" + flavor + ").");
        }
    }

    public void applyDiscount(int discountCode) {
        if (discountCode == 1234) { // Example discount code
            System.out.println("Discount applied successfully using code: " + discountCode + " for " + getType() + " (" + flavor + ")!");
        } else {
            System.out.println("Invalid discount code. No discount applied for " + getType() + " (" + flavor + ").");
        }
    }

    // Method to return the type of dessert
    public String getType() {
        if (this instanceof Cupcake) {
            return "Cupcake";
        } else if (this instanceof IceCream) {
            return "Ice Cream";
        } else if (this instanceof Cookie) {
            return "Cookie";
        } else {
            return "Dessert";
        }
    }
}
