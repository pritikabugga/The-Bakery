public class Cupcake extends Dessert {
    private String sprinkles;
    private String candy;


    public Cupcake(String flavor, double price, int quantity, String sprinkles, String candy) {
        super(flavor, price, quantity);
        this.sprinkles = sprinkles;
        this.candy = candy;
    }


    // Getters and setters for Cupcake specific attributes
    public String getSprinkles() {
        return sprinkles;
    }


    public void setSprinkles(String sprinkles) {
        this.sprinkles = sprinkles;
    }


    public String getCandy() {
        return candy;
    }


    public void setCandy(String candy) {
        this.candy = candy;
    }


    // Override toString() method to include sprinkles and candy
    @Override
    public String toString() {
        return super.toString() + ", Sprinkles: " + sprinkles + ", Candy: " + candy;
    }
}
