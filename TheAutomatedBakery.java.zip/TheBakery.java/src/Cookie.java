public class Cookie extends Dessert {
    private boolean chocolateChips;
    private boolean icing;


    public Cookie(String flavor, double price, int quantity, boolean chocolateChips, boolean icing) {
        super(flavor, price, quantity);
        this.chocolateChips = chocolateChips;
        this.icing = icing;
    }


    // Getters and setters for Cookies specific attributes
    public boolean hasChocolateChips() {
        return chocolateChips;
    }


    public void setChocolateChips(boolean chocolateChips) {
        this.chocolateChips = chocolateChips;
    }


    public boolean hasIcing() {
        return icing;
    }


    public void setIcing(boolean icing) {
        this.icing = icing;
    }


    @Override
    public String toString() {
        return super.toString() + ", Chocolate Chips: " + chocolateChips + ", Icing: " + icing;
    }
}
