import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        ArrayList<Dessert> items = new ArrayList<>();
        Bakery bakery = new Bakery();
        items = bakery.getItems();

        Scanner scnr = new Scanner(System.in);
        boolean run = true;

        while (run) {
            System.out.println("Welcome to the automated Bakery System!");
            System.out.println("Select from one of the following options:");
            System.out.println("\t1. Examine our selection");
            System.out.println("\t2. Apply Discount");
            System.out.println("\t3. Exit");

            try {
                int choice = scnr.nextInt();
                scnr.nextLine(); // Consume the newline left-over

                switch (choice) {
                    case 1:
                        System.out.println("Which type of dessert are you searching for today?");
                        System.out.println("Please enter\n\t1 - for Cupcakes\n\t2 - for Ice Creams\n\t3 - for Cookies");
                        int selection = scnr.nextInt();
                        scnr.nextLine(); // Consume the newline

                        int counter = 0;

                        for (Dessert item : items) {
                            if (selection == 1 && item instanceof Cupcake) {
                                counter++;
                                Cupcake cupcake = (Cupcake) item;
                                System.out.println(cupcake.toString());
                            } else if (selection == 2 && item instanceof IceCream) {
                                counter++;
                                IceCream iceCream = (IceCream) item;
                                System.out.println(iceCream.toString());
                            } else if (selection == 3 && item instanceof Cookie) {
                                counter++;
                                Cookie cookie = (Cookie) item;
                                System.out.println(cookie.toString());
                            }
                        }

                        if (counter == 0) {
                            System.out.println("No desserts of this type available.");
                        } else {
                            System.out.println("There are " + counter + " dessert(s) available for purchase");
                        }
                        break;

                    case 2:
                        System.out.println("Enter discount code or percentage (it will be taken into consideration at checkout):");
                        try {
                            double discountValue = scnr.nextDouble();
                            scnr.nextLine(); // Consume the newline

                            if (discountValue >= 5 && discountValue <= 40) {
                                // Valid percentage discount
                                for (Dessert item : items) {
                                    item.applyDiscount(discountValue); // Apply percentage discount
                                }
                                System.out.println("Discount of " + discountValue + "% will be applied successfully at checkout!");
                            } else if (isValidDiscountCode((int) discountValue)) {
                                // Valid discount code
                                for (Dessert item : items) {
                                    item.applyDiscount((int) discountValue); // Apply discount by code
                                }
                                System.out.println("Discount applied successfully using code: " + (int) discountValue);
                            } else {
                                System.out.println("Invalid discount value! Percentage discount should be between 5 and 40, or enter a valid discount code.");
                            }
                        } catch (InputMismatchException e) {
                            System.out.println("Invalid input! Please enter a valid number for the discount.");
                            scnr.next(); // Clear the invalid input from the scanner
                        }
                        break;

                    case 3:
                        run = false;
                        break;
                    default:
                        System.out.println("Invalid input, try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a number.");
                scnr.next(); // Clear the invalid input from the scanner
            }
        }
        scnr.close();
    }

    // Method to validate discount code
    private static boolean isValidDiscountCode(int code) {
        return code == 1234;
    }
}
